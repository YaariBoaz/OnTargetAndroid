export interface InventoryModel {
    userId: string;
    wepons: Array<string>;
    sight: Array<string>;
}
