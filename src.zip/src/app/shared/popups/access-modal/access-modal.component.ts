import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-access-modal',
    templateUrl: './access-modal.component.html',
    styleUrls: ['./access-modal.component.scss'],
})
export class AccessModalComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }

    closeModal() {

    }

    continueToThird() {

    }

    returnToPreviusStage() {

    }
}
